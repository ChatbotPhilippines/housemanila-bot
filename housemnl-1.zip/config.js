const config = {
  appID : "205bddac-3dd5-466e-91de-a49e466250ba",
  appPassword : "hVRQxv7t6yb4uVoVvwVdwg1",
  MAILGUN_API_KEY: "key-2cc6875066bce7da401337300237471d",
  MAILGUN_DOMAIN_KEY: "sandboxb18d41951b2a4b58a7f2bcdc7a7048f8.mailgun.org",
  FB_PAGE_TOKEN: "EAAcMbSiRTlABADYKZAfOzLxQlKBrAsQ17r2amdwZAZBbEeJCHzXWnsLTMdDzqEb2duFTQ3xhZBR9NTYXK8qWRgPn9hvMNuZBCYY4I3B7S1QfJuTEDxbsOmyl59hUrXdkDJ1zEWl7sptV5QN6f8wPZC1hoJA9ZC1qAjhp9v0tBqJlAZDZD"
}

module.exports = config;